<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/footer.css">
</head>
<body>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> Copyright KELOMPOK 7_TIF221PB_UASWEB1</p>
    </footer>
</body>
</html>